package com.cg.payroll.beans;

public class Address {

}
