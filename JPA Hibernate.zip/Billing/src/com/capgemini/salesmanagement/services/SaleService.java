package com.capgemini.salesmanagement.services;

import java.util.HashMap;


import com.capgemini.salesmanagement.beans.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;
import com.capgemini.salesmanagement.dao.SaleDAO;
import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductCodeException;
import com.capgemini.salesmanagement.exceptions.InvalidProductNameException;
import com.capgemini.salesmanagement.exceptions.InvalidProductPriceException;
import com.capgemini.salesmanagement.exceptions.InvalidProductQuantityException;

public class SaleService implements ISaleService {
	ISaleDAO saleDao=new SaleDAO();
	String prodCat = null;
	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		return saleDao.insertSalesDEtails(sale);

	}

	@Override
	public boolean validateProductCode(int productId) throws InvalidProductCodeException {
		if((productId<=1005)&&(productId>=1001)) {
			return true;
		}
		else throw new InvalidProductCodeException("invalid product code");
	}

	@Override
	public boolean validateProductCategory(String productCat) throws InvalidProductCategoryException {
		if(productCat.equalsIgnoreCase("Electronics")||productCat.equalsIgnoreCase("Toys")) {
			prodCat=productCat;
			return true;
		}
		else throw new InvalidProductCategoryException("invalid product category");
	}

	@Override
	public boolean validateProductPrice(int productPrice) throws InvalidProductPriceException {
		if(productPrice>=200) {
			return true;
		}
		else throw new InvalidProductPriceException("not valid price");
	}

	@Override
	public boolean validateProductQuantity(int productquantity) throws InvalidProductQuantityException {
		if((productquantity<=5)&&(productquantity>=2)) {
			return true;
		}
		else throw new InvalidProductQuantityException("not valid quantity");
	}

	@Override
	public boolean validateProductName(String productName) throws InvalidProductNameException {
		if(prodCat.equalsIgnoreCase("Electronics")&&(productName.equalsIgnoreCase("Tv")||productName.equalsIgnoreCase("Smart Phone")||productName.equalsIgnoreCase("Video Game")))
			return true;

		else if((prodCat.equalsIgnoreCase("Toys")&&productName.equalsIgnoreCase("Soft Toy")||productName.equalsIgnoreCase("Telescope")||productName.equalsIgnoreCase("Barbee Doll")))
			return true;

		else 
			throw new InvalidProductNameException("product name is not valid");


	}


}
