package com.capgemini.takehome.test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.salesmanagement.beans.Sale;
import com.capgemini.salesmanagement.exceptions.InvalidProductCategoryException;
import com.capgemini.salesmanagement.exceptions.InvalidProductCodeException;
import com.capgemini.salesmanagement.exceptions.InvalidProductQuantityException;
import com.capgemini.salesmanagement.services.ISaleService;
import com.capgemini.salesmanagement.services.SaleService;
import com.capgemini.salesmanagement.util.CollectionUtil;

public class TestClass {

	public static  ISaleService services;
	LocalDate localDate=LocalDate.now();
	 
	@BeforeClass
	public static void setUpTestEnv() {
		services=new SaleService();
	}
	@Before
	public  void setUpTestData() {
		Sale sale1=new Sale(101,1002,"TV","Electronics",3,localDate,75000);
		Sale sale2=new Sale(102,1003,"Telescope","Toys",2,localDate,15000);
		CollectionUtil.getCollection().put(101,sale1);
		CollectionUtil.getCollection().put(102,sale2);
	}
	@Test(expected=InvalidProductCodeException.class)
	public void testProductCodeForInvalidId()throws InvalidProductCodeException{
		services.validateProductCode(12345);
	}
	@Test
	public void testProductCodeForValidId()throws InvalidProductCodeException{
		boolean expectedValue=true;
		boolean actualValue=services.validateProductCode(1002);
		Assert.assertEquals(expectedValue,actualValue);
	}
	@Test(expected=InvalidProductCategoryException.class)
	public void testProductCategoryForInvalidInput()throws InvalidProductCategoryException{
		services.validateProductCategory("medicines");
	}
	@Test
	public void testProductCategoryForValidInput()throws InvalidProductCategoryException{
		services.validateProductCategory("Electronics");
	}
	@Test(expected=InvalidProductQuantityException.class)
	public void testProductQuantityForInvalidInput()throws InvalidProductQuantityException{
		services.validateProductQuantity(0);
	}
	@Test
	public void testProductQuantityForValidInput()throws InvalidProductQuantityException{
		services.validateProductQuantity(3);
	}

	@After
	public void tearDownTestData() {
		CollectionUtil.getCollection().clear();
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		services = null ;
	}
}
