package com.cg.payroll.services;
import com.cg.payroll.daoservices.*;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.exception.AssociateDetailNotFoundException;
import java.util.List;

public class PayrollServiceImpl implements payrollServices  {
	private AssociateDao associateDao=new AssociateDAOImpl();

	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder8oC, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) {
        /*BankDetails bankDetails=new BankDetails(accountNumber,bankName,ifscCode);
        Salary salary=new Salary(basicSalary, epf, companyPf);
        Associate associate=new Associate(yearlyInvestmentUnder8oC,firstName,lastName,department,designation,pancard,emailId);*/
	    Associate associate = new Associate(yearlyInvestmentUnder8oC,firstName,lastName,department,designation,pancard,emailId,new Salary(basicSalary, epf, companyPf),new BankDetails(accountNumber, bankName,ifscCode));
	    associate=associateDao.save(associate);
		return associate.getAssociateId();
	}
	
	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailNotFoundException {
		Associate associate=getAssociateDetails(associateId);
		
		return 0;
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailNotFoundException {
		Associate associate=associateDao.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailNotFoundException("Associate details not found for id"+associateId);
		return associate;
	}

	@Override
	public List<Associate>getAssociateDetails() {
		
		return associateDao.findAll();
	}
	
	
} 

	